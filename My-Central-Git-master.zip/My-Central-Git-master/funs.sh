#! /bin/bash

echo "Function"

function fu()
 
{
	echo "this is the function body"
	
}

fu
