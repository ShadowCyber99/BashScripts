#! /bin/bash

declare -r pwdfile=/etc/passwd # read only varible

echo $pwdfile

pwdfile=/home/ghost

echo $pwdfile
