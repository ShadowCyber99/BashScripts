#! /bin/bash

./string.sh

echo "The message from Shadow is : $MESSAGE"

