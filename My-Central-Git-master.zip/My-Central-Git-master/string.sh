#! /bin/bash

echo "String"

MESSAGE="Shadow Cyber"
export MESSAGE
./string2.sh

