#! /bin/bash
#
inotifywait -m /home/ghost/Shadow/Bash
