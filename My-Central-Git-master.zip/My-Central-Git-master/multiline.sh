#! /bin/bash

cat >> redirection.sh

delimator


